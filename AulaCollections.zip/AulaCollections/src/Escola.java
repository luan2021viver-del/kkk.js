import java.util.ArrayList;
public class Escola {

	private String nome;
	private ArrayList<Aluno> alunos = new ArrayList<Aluno>();
	
	public Escola (String nome) {
		this.nome = nome;
	}
	public void adicionarAluno(Aluno aluno) {
		if(alunos.contains(buscarAluno(aluno.getCpf()))) {
			System.out.println("aluno ja existente");
		} else {
			System.out.println("Aluno Adicionado a escola");
		}
		alunos.add(aluno);
	}
	public Aluno buscarAluno(String cpf) {
		for (Aluno aluno : aluno) {
			if(aluno.getCpf().equals(cpf)) {
				System.out.println("Aluno Encontrado");
				return aluno;
			}
		}
		return null;
	}
	public void removerAluno(String cpf) {
		System.out.println(a -> a.getCpf().equals(cpf)) ? "Aluno Removido" : "Aluno não Encontrado!");
			
		
	}
	
	
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public ArrayList<Aluno> getAlunos() {
		return alunos;
	}
	public void setAlunos(ArrayList<Aluno> alunos) {
		this.alunos = alunos;
	}
	
	
}
