import java.util.List;
import java.util.ArrayList;

public class Collections  {
	
     public static void main(String [] args) {
	  
    	Escola senai = new Escola("senai");
    	
    	Aluno aluno1 = new Aluno("Erik",24,"23456789123",7.1,6.5);
    	Aluno aluno1 = new Aluno("John",18,"23456789122",7.1,7.5);
    	
    	
    	
    	senai.adicionarAluno(aluno1);
    	senai.adicionarAluno(aluno2);
    	
    	 
     }
}
