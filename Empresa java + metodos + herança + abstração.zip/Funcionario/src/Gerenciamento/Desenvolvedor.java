package Gerenciamento;

class Desenvolvedor extends Trabalhador {

	@Override
	public double calcularSalario() {
		return salarioBase + (salarioBase * 0.10);
	}
	   public boolean autenticar(String senha) {
	        return senha.equals("54321");
	    }
	}