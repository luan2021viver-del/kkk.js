package Gerenciamento;
public class Gerente extends Trabalhador implements Autenticavel {

	
    @Override
    public double calcularSalario() {
        return salarioBase + (salarioBase * 0.20);
    }

    public boolean autenticar(String senha) {
        return senha.equals("12345");
    }
}