package Gerenciamento;

abstract class Trabalhador {
    String nome;
    double salarioBase;

    public void exibirDados() {
        System.out.println("Nome: " + nome);
        System.out.println("Salário Base: " + salarioBase);
    }

   
    public abstract double calcularSalario();
}