package Gerenciamento;

import java.util.ArrayList;

public class Empresa {

    public static void main(String[] args) {
      
        ArrayList<Trabalhador> listaTrabalhadores = new ArrayList<>();

        
        Gerente gerente1 = new Gerente();
        gerente1.nome = "Carlos Silva";
        gerente1.salarioBase = 5000.0;

        Desenvolvedor dev1 = new Desenvolvedor();
        dev1.nome = "Mariana Souza";
        dev1.salarioBase = 4000.0;

        listaTrabalhadores.add(gerente1);
        listaTrabalhadores.add(dev1);

       
        for (Trabalhador t : listaTrabalhadores) {
            t.exibirDados();
            System.out.println("Salário Final com Bônus: R$ " + t.calcularSalario());
            System.out.println("--------------------------------------------------");
        }

    
        boolean senhaCorreta = gerente1.autenticar("12345");
        if (senhaCorreta) {
            System.out.println("Acesso Permitido: Gerente " + gerente1.nome + " autenticado com sucesso!");
        } else {
            System.out.println("Acesso Negado: Senha incorreta.");
        }
    }
}