package br.senai.aula;

public class Calculadora {
	public int somar(int a,int b) {
		return a+b;
	}
   public boolean ehPar (int n) {
	   return n%2 ==0;
   }
   

public class Subtração {
	public int subtrair(int d,int c) {
		return d-c;
	}
	


	public int divisao(int e,int h) {
		if(h<0);
		Illegalexception();
		return e/h;
	}
  
  

}

public void Illegalexception() {
	// TODO Auto-generated method stub
	
}
}