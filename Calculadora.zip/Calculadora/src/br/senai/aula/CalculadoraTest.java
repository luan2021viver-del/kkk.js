package br.senai.aula;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CalculadoraTest {

	@Test
	void somar() {
		Calculadora calc = new Calculadora();
		assertEquals(9, calc.somar(4,5));
		
	}
	
	@Test
	void ehPar() {
		Calculadora calc = new Calculadora();
		assertTrue( calc.ehPar(16));
		assertFalse( calc.ehPar(25));
		
	}

	@Test
	void Subtrair() {
		Calculadora calc = new Calculadora();
		assertEquals(5, calc.subtrair(9,4));
		
	}
	@Test
	void CalculadoraD() {
		Calculadora calc = new Calculadora();
		assertTrue(8, calc.divisao(16,2));
		
	}



}
